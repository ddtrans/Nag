package com.training.nagarro.ADVANCE_JAVA_ASS_2.file_reader;

import java.io.*;
import java.nio.file.Path;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;


import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.CsvToBeanBuilder;
import com.training.nagarro.ADVANCE_JAVA_ASS_2.TShirt;


public class CsvFileReader {
	
	private final static CsvFileReader fileReader = new CsvFileReader();
	
	private final List<String> fileNames;
	private Path dirPath;
	
	private CsvFileReader() {
		fileNames = new LinkedList<>();
	}
	
	public static CsvFileReader getCsvFileReaderInstance() {
		return fileReader;
	}
	
	private List<TShirt> readDataToBean(Path filePath) {
		List<TShirt> tshirt = null;
		try {
			Reader reader = new FileReader(filePath.toString());
			CsvToBean<TShirt> csvBean = new CsvToBeanBuilder<TShirt>(reader)
					.withType(TShirt.class)
					.withOrderedResults(false)
					.withSeparator('|')
					.build();
			
			tshirt =csvBean.stream().collect(Collectors.toList());
		} catch (IllegalStateException | FileNotFoundException e) {
			e.printStackTrace();
		}
		return tshirt;
		
	}
	
	public List<TShirt> readFromFiles(Path dir) {
		dirPath = dir;
		fileNames.addAll(getFileNames.apply(dir.toFile().list(fileFilter)));
		List<TShirt> tshirts = new ArrayList<>();
		for (String names : fileNames) {
			tshirts.addAll(readDataToBean(dirPath.resolve(names)));
		}
		return tshirts;
	}
	
	public List<TShirt> addNewFile(Path newFileName) {
		fileNames.add(dirPath.getFileName().toString());
		return readDataToBean(newFileName);
	}
	
   private FilenameFilter fileFilter = (File dir, String name) -> name.toLowerCase().endsWith(".csv"); 
   
   private Function<String[], List<String>> getFileNames = (names) -> Arrays.stream(names).collect(Collectors.toList()); 
}
