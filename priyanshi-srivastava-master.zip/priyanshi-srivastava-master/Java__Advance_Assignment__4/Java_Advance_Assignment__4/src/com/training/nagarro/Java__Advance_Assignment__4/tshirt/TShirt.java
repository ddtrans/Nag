package com.training.nagarro.Java_Advance_Assignment__4.tshirt;


import javax.persistence.Entity;
import javax.persistence.Id;

import com.opencsv.bean.CsvBindByName;

@Entity
public class TShirt{
	
	@CsvBindByName(column = "ID")
	@Id
	private String id;
	
	@CsvBindByName(column = "NAME")
	private String name;
	
	@CsvBindByName(column = "COLOUR")
	private String color;
	
	@CsvBindByName(column = "GENDER_RECOMMENDATION")
	private String gender;
	
	@CsvBindByName(column = "SIZE")
	private String size;
	
	@CsvBindByName(column = "PRICE")
	private float price;
	
	@CsvBindByName(column = "RATING")
	private float rating;
	
	@CsvBindByName(column = "AVAILABILITY")
	private char availability;

	public String gettID() {
		return id;
	}

	public void settID(String tID) {
		this.id = tID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public float getRating() {
		return rating;
	}

	public void setRating(float rating) {
		this.rating = rating;
	}

	public char getAvailability() {
		return availability;
	}

	public void setAvailability(char availability) {
		this.availability = availability;
	}
	@Override
	public String toString() {
		return  "[ id : " + id + " name : " + name + " color : " + color +"]";
	}

}



