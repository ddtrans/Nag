package com.training.nagarro.Java_Advance_Assignment__4.tshirt_dao;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;

import com.training.nagarro.ADVANCE_JAVA_ASS_4.tshirt.TShirt;

@Component
public class TshirtDao {

	@Autowired
	private HibernateTemplate hibernateTemplate;

	@Transactional
	public void saveTShirt(TShirt tShirt) {
		this.hibernateTemplate.saveOrUpdate(tShirt);
	}

	@SuppressWarnings("unchecked")
	public List<TShirt> findTShirt(String color,String gender,String size) {
		DetachedCriteria detachedCriteria = DetachedCriteria.forClass(TShirt.class);
		detachedCriteria.add(Restrictions.eq("color", color));
		detachedCriteria.add(Restrictions.eq("gender", gender));
		detachedCriteria.add(Restrictions.eq("size", size));
		List<TShirt> findByCriteria =  (List<TShirt>) hibernateTemplate.findByCriteria(detachedCriteria);
		
		if (findByCriteria != null && findByCriteria.size() > 0) {
			return  findByCriteria;
		} else
			findByCriteria = new ArrayList<TShirt>();
			return findByCriteria;

	}

}
