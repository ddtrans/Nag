package com.training.nagarro.Java_Advance_Assignment__4;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import com.training.nagarro.Java_Advance_Assignment__4.file_reader.CsvFileReader;
import com.training.nagarro.Java_Advance_Assignment__4.tshirt.TShirt;
import com.training.nagarro.Java_Advance_Assignment__4.tshirt_dao.TshirtDao;
import com.training.nagarro.Java_Advance_Assignment__4.user.User;
import com.training.nagarro.Java_Advance_Assignment__4.user_dao.UserDao;

@Controller
public class MainController {

	@Autowired
	private UserDao userDao;

	@Autowired
	private TshirtDao tshirtDao;

	@RequestMapping("/home")
	public String home() {
		return "index";
	}

	@RequestMapping("/")
	public String signIn() {
		return "sign_in";
	}

	@RequestMapping("/Sign_Up")
	public String signUp() {
		return "sign_up";
	}

	@RequestMapping("/ForGotPass")
	public String forGotPass() {
		return "forgot_password";
	}

	@RequestMapping("/ShowPassword")
	public String showPassword() {
		return "show_password";
	}

	@RequestMapping("/SearchTshirt")
	public String saerchTshirt(HttpServletRequest request) {
		List<TShirt> tShirts = new ArrayList<>();
		CsvFileReader csvReader = CsvFileReader.getCsvFileReaderInstance();
		Path dir = Paths.get(
				"C:\\Users\\anshubabu\\eclipse-workspace\\ADVANCE_JAVA_ASS_4\\src\\com\\training\\nagarro\\ADVANCE_JAVA_ASS_4\\data");
		tShirts.addAll(csvReader.readFromFiles(dir));
		for (TShirt tempShirt : tShirts) {
//			System.out.println(tempShirt);
			tshirtDao.saveTShirt(tempShirt);
		}
		return "search_tshirt";
	}

	@RequestMapping(value = "/Done_Sign_Up", method = RequestMethod.POST)
	public RedirectView doneSignUp(@ModelAttribute User user, HttpServletRequest request) {
		userDao.saveUser(user);
		RedirectView redirectView = new RedirectView();
		redirectView.setUrl(request.getContextPath() + "/");
		return redirectView;
	}

	@RequestMapping(value = "/Done_Sign_In", method = RequestMethod.POST)
	public RedirectView doneSignIn(@ModelAttribute User user, HttpServletRequest request) {
		User tempUser = userDao.findUser(user);
		RedirectView redirectView = new RedirectView();
		if (tempUser == null) {
			redirectView.setUrl(request.getContextPath() + "/");
		} else {
			redirectView.setUrl(request.getContextPath() + "/SearchTshirt");
		}
		return redirectView;
	}

	@RequestMapping(value = "/DoneForGotPass", method = RequestMethod.POST)
	public ModelAndView doneForGotPass(@RequestParam("user_name") String user_name) {
		User tempUser = userDao.findPassWord(user_name);
		ModelAndView modelAndView = new ModelAndView();
		if (tempUser == null) {
			modelAndView.setViewName("forgot_password");
		} else {
			modelAndView.addObject("user", tempUser);
			modelAndView.setViewName("show_password");
		}
		return modelAndView;
	}

	@RequestMapping(value = "/Show_Tshirt", method = RequestMethod.POST)
	public ModelAndView searchTshirt(@RequestParam("color") String color, @RequestParam("gender") String gender,
			@RequestParam("size") String size, @RequestParam("sortingTechnique") String sortingTechnique) {
		List<TShirt> tShirts = (List<TShirt>) tshirtDao.findTShirt(color, gender, size);
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("tShirts", tShirts);
		modelAndView.setViewName("show_tshirt");
		return modelAndView;
	}
}
