package com.training.nagarro.ADVANCE_JAVA_ASS_1.util;

public enum Size {
	
		S("Small"),
		M("Medium"),
		L("Large"),
		XL("Xtra Large"),
		XLL("Double XL");
		
		private String size;
		
		private Size(String size) {
			this.size = size;
		}
		
		public String getSize() {
			return size;
		}

	}


	
