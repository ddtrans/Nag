package com.training.nagarro.ADVANCE_JAVA_ASS_1.util;

public enum Gender {
	
	M("Male"),
	F("Female"),
	U("Unisex");
	
	private String gender;
	
	private Gender(String gender) {
		this.gender = gender;
	}
	
	public String getGender() {
		return gender;
	}
}



