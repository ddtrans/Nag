package com.training.nagarro.ADVANCE_JAVA_ASS_1.mapper;

import java.util.Comparator;

import com.training.nagarro.ADVANCE_JAVA_ASS_1.TShirt;


public class Mapper {
	
	private static final Comparator<TShirt> comparisionByRating = Comparator.comparing(TShirt :: getRating);
	private static final Comparator<TShirt> comparisionByPrice = Comparator.comparing(TShirt :: getPrice);
	
	public static String mapGender(int genderChoice) {
		String gender;
		switch(genderChoice) {
		case 1:
			gender = "M";
			break;
		case 2:
			gender = "F";
			break;
		default:
			gender = "M";
		}
		return gender;
	}
	
	public static String mapSize(int sizeChoice) {
		String size;
		switch(sizeChoice) {
		case 1:
			size = "S";
			break;
		case 2:
			size = "M";
			break;
		case 3:
			size = "L";
			break;
		case 4:
			size = "XL";
			break;
		case 5:
			size = "XXL";
			break;
		default:
			size = "S";
		}
		return size;
	}
	
	public static Comparator<TShirt> mapSortingTechinque(int sortingTechniqueChoice) {
		Comparator<TShirt> sortingTechnique;
		switch(sortingTechniqueChoice) {
		case 1: 
			sortingTechnique = comparisionByPrice;
			break;
		case 2:
			sortingTechnique = comparisionByRating;
			break;
		case 3:
			sortingTechnique = comparisionByPrice.thenComparing(comparisionByRating);
			break;
		default:
			sortingTechnique = comparisionByPrice;
		}
		return sortingTechnique;
	}

}
