package com.training.nagarro.ADVANCE_JAVA_ASS_1;

import java.util.function.Predicate;

import com.opencsv.bean.BeanVerifier;
import com.opencsv.exceptions.CsvConstraintViolationException;

public class TShirtFilter implements BeanVerifier<TShirt> {
	public synchronized boolean verifyBean(TShirt bean) throws CsvConstraintViolationException {
		return colour.test(bean.getColor()) && gender.test(bean.getGender().toString()) && size.test(bean.getSize().toString());
	}
	
	private Predicate<String> colour = colour -> colour.equalsIgnoreCase(App.colour);
	private Predicate<String> gender = gender -> gender.equalsIgnoreCase(App.gender) || gender.equalsIgnoreCase("U");
	private Predicate<String> size = size -> size.equalsIgnoreCase(App.size);
	

}
