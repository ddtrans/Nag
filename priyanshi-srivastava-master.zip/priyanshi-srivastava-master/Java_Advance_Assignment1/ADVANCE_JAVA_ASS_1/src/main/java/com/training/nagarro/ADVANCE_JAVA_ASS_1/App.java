package com.training.nagarro.ADVANCE_JAVA_ASS_1;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

import com.training.nagarro.ADVANCE_JAVA_ASS_1.file_reader.CsvFileReader;
import com.training.nagarro.ADVANCE_JAVA_ASS_1.mapper.Mapper;

public class App {
	public static String size;
	public static String gender;
	public static String colour;

	public static Comparator<TShirt> sortingChoice;
	public static List<TShirt> tShirts = new ArrayList<>();

	public static void main(String[] args) {

		try (Scanner sc = new Scanner(System.in)) {
			takeUserInput(sc);
			CsvFileReader csvReader = CsvFileReader.getCsvFileReaderInstance();
			Path dir = Paths.get("C:\\Users\\anshubabu\\Downloads\\AD_JAVA\\Assigment Links");
			tShirts.addAll(csvReader.readFromFiles(dir));
			try {
				tShirts.sort(sortingChoice);
				show();
			} catch (IllegalStateException e) {
				System.out.println(e.getMessage());
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private static void takeUserInput(Scanner sc) {

		try {
			System.out.print("Enter Colour Of T-Shirt-->\n-> ");
			colour = sc.nextLine();

			System.out.println("Choose Size Of T-Shirt-->");
			System.out.print("1 :- Small\n2 :- Medium\n3 :- Large\n4 :- Xtra Large\n5 :- Double XL\n-> ");
			int sizeChoice = Integer.parseInt(sc.nextLine());
			size = Mapper.mapSize(sizeChoice);

			System.out.println("Choose Your Gender-->");
			System.out.print("1 :- Male\n2 :- Female\n-> ");
			int genderChoice = Integer.parseInt(sc.nextLine());
			gender = Mapper.mapGender(genderChoice);

			System.out.println("Sort Data By-->");
			System.out.print("1 :- Price\n2 :- Rating\n3 :- Price and Rating\n-> ");
			int sortingTechniqueChoice = Integer.parseInt(sc.nextLine());
			sortingChoice = Mapper.mapSortingTechinque(sortingTechniqueChoice);
		} catch (Exception e) {
			System.out.println(e);
			System.out.println("Please Enter Right Details");
			takeUserInput(sc);
		}
	}

	private static void show() throws Exception {
		if (tShirts.isEmpty()) {
			throw new Exception("Sorry no match found");
		}
		for (TShirt tshirt : tShirts) {
			System.out.println(tshirt);
		}
	}

}
