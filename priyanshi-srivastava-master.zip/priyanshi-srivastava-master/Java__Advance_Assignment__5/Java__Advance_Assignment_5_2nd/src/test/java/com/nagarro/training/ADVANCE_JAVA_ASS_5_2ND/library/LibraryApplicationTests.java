package com.nagarro.training.ADVANCE_JAVA_ASS_5_2ND.library;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryApplicationTests {

	@Test
	void contextLoads() {
	}

}
