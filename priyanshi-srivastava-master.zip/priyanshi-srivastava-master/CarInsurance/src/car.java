import java.util.*;

public class car{
	
	private static final Scanner sc = new Scanner(System.in);

	static void calPremium(double price, int car_Type, int insurance_Type) {
		double premium = 0d;
		
		                                                   /* calculating premium according to the car type user entered */
	    switch(car_Type) {
	    case 1:{
	    	premium=(price*5)/100;
	    	break;
	    }
	    case 2:{
	    	premium=(price*8)/100;
	    	break;
	    }
	    default:{
	    	premium=(price*10)/100;
	    	break;
	    }
	    }
	    
	                                                      /* calculating premium according to the insurance type user entered */	
	    if (insurance_Type == 2) { 
	    	premium = premium +(premium * 20) / 100;
	    }  
	    	    
	    System.out.println("Total insurance to be paid: " + premium);
	}
	
	static boolean exit() {
		                                                /*  this method will run until valid information is entered by the user  */
		
		System.out.print("Do you want to enter details of any other car (Y/N): ");
		String ch =  sc.nextLine();
		boolean ans;
		if (ch.equals("Y") || ch.equals("y")) { 
			ans = false; 
		} else if (ch.equals("N") || ch.equals("n")) { 
		    ans = true; 
		} else {
			System.out.println("You have entered invalid input");
			ans = exit();
		}
		return ans;
	}
	
	static int type() {
		                                                        /*  this method will run until valid information is entered by the user  */
		
		System.out.println("select Car Type ");
		System.out.println("Enter 1 for Hatchback");
		System.out.println("Enter 2 for Sedan");
		System.out.println("Enter 3 for SUV");
		System.out.print("Enter Choice- ");
		int n=sc.nextInt();
		int result;
		switch(n) {
		case 1:{
			result=1;
			break;}
		case 2:{
			result=2;
			break;
		}
		case 3:{
			result=3;
			break;
		}
		default:{
			System.out.println("PLEASE ENTER CORRECT INPUT");
			result=type();
			break;
			
		}
		}
		return result;
	}
	
	static double price() {
		                                                 /*  this method will run until valid information is entered by the user  */
		System.out.print("Enter cost price of Car ");
		double price = 0;
		try {
			price = Double.parseDouble(sc.nextLine());
		} catch (Exception e) {
			System.out.println("Invalid price you have entered");
			price = price();
		}
		return price;
	}
	
	static int insuranceType() {
		/* this will run until valid information is entered by the user */
		System.out.println("select Type of Insurance  ");
		System.out.println("Enter 1 for Basic Insurance");
		System.out.println("Enter 2 for Premium Insurance");		
		System.out.print("Enter your choice"+sc.nextLine());
		String choice= sc.nextLine();
		int re_sult;
		if(choice.equals("1")) {
			re_sult=1;
		}else if(choice.equals("2")) {
			re_sult=2;
		}else {
			System.out.println("PLEASE ENTER CORRECT INPUT");
			re_sult=insuranceType();
		}

		return re_sult;
	}
	
	static String c_model() {
		System.out.print("Enter Model of the Car: ");
		String model_car = sc.nextLine();
		return model_car;
	}

	public static void main(String[] args) {
		LinkedList<String> car_model = new LinkedList<>();                   /* initializing the linked list for storing model*/
		LinkedList<Integer> type = new LinkedList<>();                       /*  vehicle type, price of vehicle and insurance type. */
		LinkedList<Double> cost_price = new LinkedList<>();                      
		LinkedList<Integer> insurance_Type = new LinkedList<>();          
		
		while(true) {
			car_model.add(c_model());                                      /* taking inputs from the user until user doesn't want to enter */
			type.add(type());                                              /* information of another car.*/
			cost_price.add(price());                                      
			insurance_Type.add(insuranceType());
			if (exit()) { 
				break; 
			}
		}
		
		for (int i =0; i < car_model.size(); i++) {
			                                                                                  /* prints out the information user entered */
			System.out.println("Model of the car: " + car_model.get(i));                     /*  and calculated premium */
			System.out.println("Price of car: " + cost_price.get(i));                      
			calPremium(cost_price.get(i), type.get(i), insurance_Type.get(i));              
		}
	}
}