package nagarro.training.assignment;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Driver driver_obj = new Driver();
        driver_obj.executiveFunction();
    

	}

}
