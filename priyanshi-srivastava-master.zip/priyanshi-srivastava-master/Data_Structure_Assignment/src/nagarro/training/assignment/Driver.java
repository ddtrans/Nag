package nagarro.training.assignment;

import training.assignment.prior.queue.*;
import stack.*;
import queue.*;
import linkedList.*;
import hashtable.*;

@SuppressWarnings("unused")
public class Driver {
	public void executiveFunction() {
		
	                       	//IMPLEMENTATION OF LINKED LIST 
/*		
    LinkedListImp<Integer>  newList= new LinkedListImp<Integer>();
      newList.insertAtLast(5);
      newList.insertAtLast(9);
      newList.insertAtLast(2);
      newList.insertAtLast(4);
      newList.insertAtLast(3);

      System.out.println("Elements are : ");
      newList.printLinkedList();


      newList.insertAtGivenPosition(11,1);
      System.out.println("\nAfter insertion Elements are : ");
      newList.printLinkedList();
      newList.insertAtGivenPosition(11,8);

      newList.deleteAtGivenPosition(4);
      System.out.println("\nAfter Deletion Elements are : ");
      newList.printLinkedList();

      System.out.println("\nCenter Element is : "+newList.returnCenter());
      
      System.out.println("\nElements are : ");
      newList.printLinkedList();     
*/
		
		
                         //IMPLEMENTATION OF STACK 

/*	  StackImplementation<Integer> stack = new StackImplementation<>();
      System.out.println("Size is : " + stack.size());
      stack.push(8);
      stack.push(3);
      stack.push(1);
      stack.push(5);
      stack.push(9);
      System.out.print("Elements are : ");
      stack.print();

      stack.pop();
      stack.pop();
     System.out.println("Size : " + stack.size());
     System.out.print("Elements : ");
     stack.print();
     
     
     System.out.println(stack.contains(3));
     stack.reverse();
     System.out.print("Elements are : ");
     stack.print();
  
*/     
      // IMPLEMENTATION OF QUEUE
      
 /*    QueueImp<Double> queues = new QueueImp<>();
      queues.enqueue(1.42);
      queues.enqueue(2.50);
      queues.enqueue(3.7);
      queues.enqueue(4.2);
      queues.enqueue(5.34);
      System.out.print("Elements are : ");
      queues.print();

      System.out.println("Top Element is : " + queues.peek());
      System.out.println("isContain : "+queues.contains(5.34));
      queues.dequeue();
      queues.dequeue();

      System.out.println("Size is : "+queues.size());
      System.out.print("Elements are : ");
      queues.print();
       
      System.out.println("Center is :"+queues.center().data);
      queues.reverse();
      
      System.out.print("Reversed Elements is : ");
      queues.print();
      
*/		
		
      //IMPLEMENTATION OF PRIORITY_QUEUE 
      
/*      PriorityQueueImplementation pqueue = new PriorityQueueImplementation();
      pqueue.enqueue(72);
      pqueue.enqueue(14);
      pqueue.enqueue(9);
      pqueue.enqueue(12);
      pqueue.enqueue(7);
      pqueue.enqueue(3);
      System.out.println("Top Element : " + pqueue.peek());
      System.out.print("Elements : ");
      pqueue.print();

      System.out.println("Size " + ": " +pqueue.size());

      pqueue.dequeue();
      pqueue.dequeue();

      System.out.println("Top Element : " + pqueue.peek());

      System.out.print("Elements are : ");
      pqueue.print();
      
      pqueue.enqueue(5);
      pqueue.enqueue(8);

      System.out.println("Elements are after insertion:");
      pqueue.print();
 */     
     
    
              //IMPLEMENTATION OF HASHMAP 

/*   HashTableImple<Integer, Integer> mMap = new HashTableImple<Integer, Integer>();
      mMap.insert(21, 12);
      mMap.insert(30, 151);
      mMap.insert(22, 15);
      mMap.insert(19, 89);

      System.out.println("value corresponding to key 21="
              + mMap.get(21));
      System.out.println("value corresponding to key 51="
              + mMap.get(51));
      
      System.out.println(mMap.contains(55));
      System.out.print("Printing : ");
      mMap.print();

      System.out.println("\n value corresponding to key 21 removed: "
              + mMap.delete(21));
      System.out.println("value corresponding to key 51 removed: "
              + mMap.delete(51));

      System.out.println("Printing : ");
      mMap.print();
      
      System.out.println("\n"+mMap.size());

 */ 
	}

}
