package linkedList;

public class LinkedListImp<T> {
	   
    private LinkedListNodes<T> head;
    private int count;

    public LinkedListImp() {
        head = null;
        count= 0;
    }
	
	//INSERT AT LAST IN LINKED LIST
	public void insertAtLast(T data) {
		LinkedListNodes<T> newNode= new LinkedListNodes<T> (data);
		
		if(head==null) {
			head=newNode;
		}else {
			LinkedListNodes<T> temp=head;
			while(temp.next!=null)
			{
				temp=temp.next;
			}
			temp.next=newNode;
		}
		count++;
	}
	
	                                                            //INSERT AT ANY GIVEN POSITION
	
	public void insertAtGivenPosition(T data,int position) {
        
		LinkedListNodes<T> newNode=new LinkedListNodes<>(data);
		if (position==0)
        {
            newNode.next=head;
            head=newNode;
        }
        else if(position>0&&position<count+2)
        {
            int i=0;
            LinkedListNodes<T> temp=head;
        	for (i=0;i<position-1 && temp!=null;i++){
            	temp=temp.next;
        	}
        	
        	if (temp!=null && position>0){
            	newNode.next=temp.next;
            	temp.next=newNode;
        	}
        }
        else {
        	try {
        		
        	throw new InsertAtValidLocationException();
        	
        	}catch(InsertAtValidLocationException e) {
        		System.out.println("\n"+e);
        	}
        }
		count++;
	}

	
	//DELETE LAST ELEMENT IN LINKED LIST
	public LinkedListNodes<T> deleteFromLast() {
		if(head==null||head.next==null) {
			return null;
		}else {
			LinkedListNodes<T> temp=head;
			while(temp.next.next!=null)
			{
				temp=temp.next;
			}
			temp.next=null;
			count--;
			return head;
		}
	}
	
	
	//DELETE ELEMENT AT GIVEN POSITION IN LINKED LIST
	public LinkedListNodes<T> deleteAtGivenPosition(int pos) {

        if (pos<0){
            return head;
        }else if(pos==0){
            head=head.next;
        }else{
            LinkedListNodes<T> temp=head;
            for (int i=0;i<pos-1 && temp!=null;i++){
                temp=temp.next;
            }
            
            if (temp!=null && temp.next!=null){
                if (temp.next!=null){
                    temp.next=temp.next.next;
                }else{
                    temp.next=null;
                }
            }
        }
        return head;
	}

	
	//RETURN THE CENTER ELEMENT
	
	public T returnCenter()
	{
		LinkedListNodes<T> temp = head;
	    int count = 0;
	    while(temp!=null){
	        temp = temp.next;
	        count++;
	    }
	    
	     temp = head;
	    
	    int position = (count/2);
	    for(int i=0;i<position;i++){
	       temp = temp.next; 
	    }
	    
	    return temp.data;
	
	}
	
	//SORTING THE LINKED LIST
	public LinkedListNodes<T> sortList(LinkedListNodes<T> head) {
	    if (head == null || head.next == null) return head;
	    LinkedListNodes<T> slow = head, fast = head, pre = head;
	    while(fast != null && fast.next != null) {
	        pre = slow;
	        slow = slow.next;
	        fast = fast.next.next;
	    }
	    pre.next = null;
	    return merge(sortList(head), sortList(slow));
	}
	private LinkedListNodes<T> merge(LinkedListNodes<T> l1, LinkedListNodes<T> l2) {
	    if(l1 == null) return l2;
	    if(l2 == null) return l1;
	    if((int)l1.data <= (int)l2.data) {
	        l1.next = merge(l1.next, l2);
	        return l1;
	    } else {
	        l2.next = merge(l1, l2.next);
	        return l2;
	    }
	}	
	
	

	//REVERSE THE LINKED LIST
	public LinkedListNodes<T> reverseLinkedList(LinkedListNodes<T> head) {
        LinkedListNodes<T> current = head;
        if(current==null || current.next==null){
            return current;
        }
        LinkedListNodes<T> previous = null;
        LinkedListNodes<T> next = null;
        while(current!=null){
            next=current.next;
            current.next=previous;
            previous=current;
            current=next;
        }
        return previous;
    }
	
	//SIZE OF LINKED LIST
	public int size() {
	  return count;
	}
	

	
	
	//PRINT THE LINKED LIST
	public void printLinkedList()
	{
		   LinkedListNodes<T> temp=head;
		   while(temp!=null)
		   {
			   System.out.print(temp.data+" ");
			   temp=temp.next;
		   }
	}

	public boolean isEmpty() {
		if(count==0)
		return true;
		else
		return false;
	}
}

