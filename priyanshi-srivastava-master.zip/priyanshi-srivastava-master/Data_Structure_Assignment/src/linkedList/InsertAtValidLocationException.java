package linkedList;

@SuppressWarnings("serial")
public class InsertAtValidLocationException extends Exception{
    public String toString() {
    	return "Element can't be Inserted, Try with Valid Index";
    }
}

