package linkedList;

public class LinkedListNodes<T> {
    
	public T data;
	public LinkedListNodes<T> next;
    
	
	public LinkedListNodes(T data) {
    	this.data = data;
    	this.next=null;
	}
	
	public LinkedListNodes<T> getNode() {
		return next;
	}

	public void setNode(LinkedListNodes<T> node) {
		this.next = node;
	}

	public T getData() {
		return data;
	}

	public void setData(T data) {
		this.data = data;
	}
}

