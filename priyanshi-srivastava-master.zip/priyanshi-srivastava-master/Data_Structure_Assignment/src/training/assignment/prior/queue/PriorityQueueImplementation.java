package training.assignment.prior.queue;

public class PriorityQueueImplementation {
    private static int size = 4;
    private int [] heap;
    private int counter;

    public PriorityQueueImplementation() {
        heap = new int[size];
        counter = 0;
    }
    public static int parent(int i) {
        return (i - 1) / 2;
    }
    public static int leftChild(int i) {
        return 2*i+1 ;
    }
    public static int rightChild(int i) {
        return 2*i + 2;
    }
    public void enqueue(int data) {
        if (counter >= size) {
            int newCapacity = 2*size;
            int [] newHeap = new int[newCapacity];

            if (counter >= 0) System.arraycopy(heap, 0, newHeap, 0, counter);
            heap = newHeap;
            size = newCapacity;
        }
        heap[counter] = data;
        counter = counter + 1;
        int i = counter - 1;
        while (i != 0 && heap[PriorityQueueImplementation.parent(i)] < heap[i]) {
            int temp = heap[i];
            heap[i] = heap[parent(i)];
            heap[parent(i)] = temp;
            i = PriorityQueueImplementation.parent(i);
        }
    }

    public void maxHeapify(int i){
        int left = PriorityQueueImplementation.leftChild(i);
        int right = PriorityQueueImplementation.rightChild(i);
        int largest = i;
        if (left <= counter && heap[left] > heap[largest]) {
            largest = left;
        }
        if (right <= counter && heap[right] > heap[largest]) {
            largest = right;
        }
        if (largest != i) {
            int temp = heap[i];
            heap[i] = heap[largest];
            heap[largest] = temp;
            maxHeapify(largest);
        }

    }
    //CURRENT ELEMENT
    public int peek() {
        return heap[0];
    }

    public int dequeue() {
        int maxItem = heap[0];
        heap[0] = heap[counter - 1];
        counter = counter - 1;
        maxHeapify(0);
        return maxItem;
    }
    //DSPLAYING
    public void print() {
        for (int i = 0; i < counter; i++) {
            System.out.print(heap[i] + " ");
        }
        System.out.println();
    }
    //SIZE
    public int size() {
        return counter;
    }
}


