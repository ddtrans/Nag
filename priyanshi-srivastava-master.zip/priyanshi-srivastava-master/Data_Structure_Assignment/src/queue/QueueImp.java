package queue;

public class QueueImp<E> {
    private QueueNodeImp<E> head;
    private int elementCount;

    public QueueImp() {
        head = null;
        elementCount = 0;
    }

    public void enqueue(E data) {
    	QueueNodeImp<E> newNode = new QueueNodeImp<>(data);
        if (head == null) {
            head = newNode;
        } else {
        	QueueNodeImp<E> temp = head;
            while(temp.next != null) {
                temp = temp.next;
            }

            temp.next = newNode;
        }
        elementCount++;
    }

    public void dequeue() {
        if(head == null) {
            System.out.println("Queue is Empty. Invalid Operation.");
        }

        head = head.next;
        elementCount--;
    }

    public E peek() {
        if(head == null) {
            System.out.println("Queue is Empty. Invalid Operation.");
        }

        return head.data;
    }
    //ELEMENT PRESENT OR NOT
    public boolean contains(E element) {
        if(head == null) {
            System.out.println("Queue is Empty. Invalid Operation.");
        }

        boolean flag = false;
        QueueNodeImp<E> temp = head;
        while(temp != null) {
            if(temp.data.equals(element)) {
                flag = true;
                break;
            }
            temp = temp.next;
        }
        return flag;
    }
    //SIZE

    public int size() {
        return elementCount;
    }
    //MIDDLE ELEMENT
    
    public QueueNodeImp<E> center() {
        if(head == null) {
            System.out.println("List is Empty. Invalid Operation.");
        } else if(head.next == null) {
            return head;
        } else {
        	QueueNodeImp<E> slow = head;
        	QueueNodeImp<E> fast = head;

            while(fast != null && fast.next != null) {
                slow = slow.next;
                fast = fast.next.next;
            }

            return slow;
        }

        return null;
    }
    
    //REVERSING QUEUE

    public void reverse() {
    	QueueNodeImp<E> prev = null;
    	QueueNodeImp<E> current = head;
    	QueueNodeImp<E> next = null;
        while (current != null) {
            next = current.next;
            current.next = prev;
            prev = current;
            current = next;
        }
        head = prev;
    }
    //DISPLAYING
    public void print() {
        if(head == null) {
            System.out.println("Queue is Empty. Invalid Operation.");
        }

        QueueNodeImp<E> temp = head;
        while(temp != null) {
            System.out.print(temp.data+" ");
            temp = temp.next;
        }

        System.out.println(" ");
    }
   
}
