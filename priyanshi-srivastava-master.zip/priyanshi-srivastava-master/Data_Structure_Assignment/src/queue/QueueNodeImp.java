package queue;

public class QueueNodeImp<E> {
    public E data;
    public QueueNodeImp<E> next;

    QueueNodeImp(E data) {
        this.data = data;
        this.next = null;
    }
}

