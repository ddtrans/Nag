package stack;

public class StackNode<E> {
	public E data;
    public StackNode<E> next;

    StackNode(E data) {
        this.data = data;
        this.next = null;
    }
}

