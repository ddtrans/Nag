package stack;

public class StackImplementation<E> {
    private StackNode<E> head;
    private int elementCount;

    public StackImplementation() {
        head = null;
        elementCount = 0;
    }
    
    public boolean isEmpty() {
    	if(elementCount==0)
    		return true;
    	else
    		return false;
    }
    
    //INSERTING/PUSHING THE ELEMENT INTO STACK
    public void push(E data) {
    	StackNode<E> newNode = new StackNode<>(data);

        newNode.next = head;
        head = newNode;

        elementCount++;
    }

    public void pop() {
        if(head == null) {
            System.out.println("Stack is Empty. Invalid Operation.");
        }

        head = head.next;
        elementCount--;
    }

    public E peek() {
        if(head == null) {
            System.out.println("Stack is Empty. Invalid Operation.");
        }
        
        return head.data;
    }

    public boolean contains(E element) {
        if(head == null) {
            System.out.println("Stack is Empty. Invalid Operation.");
        }

        boolean flag = false;
        StackNode<E> temp = head;
        while(temp != null) {
            if(temp.data == element) {
                flag = true;
                break;
            }

            temp = temp.next;
        }
        return flag;
    }

    public int size() {
        return elementCount;
    }
    
    public StackNode<E> center() {
        if(head == null) {
            System.out.println("List is Empty. Invalid Operation.");
        } else if(head.next == null) {
            return head;
        } else {
        	StackNode<E> slow = head;
        	StackNode<E> fast = head;

            while(fast != null && fast.next != null) {
                slow = slow.next;
                fast = fast.next.next;
            }

            return slow;
        }

        return null;
    }
    
    //SORTING
    public StackNode<E> sortList(StackNode<E> head) {
	    if (head == null || head.next == null) return head;
	    StackNode<E> slow = head, fast = head, pre = head;
	    while(fast != null && fast.next != null) {
	        pre = slow;
	        slow = slow.next;
	        fast = fast.next.next;
	    }
	    pre.next = null;
	    return merge(sortList(head), sortList(slow));
	}

	public StackNode<E> merge(StackNode<E> l1, StackNode<E> l2) {
	    if(l1 == null) return l2;
	    if(l2 == null) return l1;
	    if((int)l1.data <= (int)l2.data) {
	        l1.next = merge(l1.next, l2);
	        return l1;
	    } else {
	        l2.next = merge(l1, l2.next);
	        return l2;
	    }
	}	



    
    //REVERSE
    public void reverse() {
    	StackNode<E> prev = null;
    	StackNode<E> current = head;
    	StackNode<E> next = null;
        while (current != null) {
            next = current.next;
            current.next = prev;
            prev = current;
            current = next;
        }
        head = prev;
    }
    
    
   //DISPLAYING
    public void print() {
        if(head == null) {
            System.out.println("Stack is Empty. Invalid Operation.");
        }

        StackNode<E> temp = head;
        while(temp != null) {
            System.out.print(temp.data+" ");
            temp = temp.next;
        }

        System.out.println(" ");
    }


}

