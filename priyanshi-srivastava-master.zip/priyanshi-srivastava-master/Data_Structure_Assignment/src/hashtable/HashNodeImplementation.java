package hashtable;

public class HashNodeImplementation<K,V> {
    K key;
    V value;
    HashNodeImplementation<K,V> next;
    
    public HashNodeImplementation(K key,V value,HashNodeImplementation<K,V> next) {
    	this.key=key;
    	this.value=value;
    	this.next=next;
    }
    
}

