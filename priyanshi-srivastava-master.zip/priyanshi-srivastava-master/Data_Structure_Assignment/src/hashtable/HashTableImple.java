package hashtable;

public class HashTableImple<K,V> {
    private final HashNodeImplementation<K,V>[] table;
    private final int capacityOfHash= 16;
    private int size;
    @SuppressWarnings("unchecked")
	public HashTableImple(){
        table = new HashNodeImplementation[this.capacityOfHash];
        size=0;
    }

    private int hash(K key){
        return Math.abs(key.hashCode()) % capacityOfHash;
    }
    //INSERT
    public void insert(K newKey, V data){
        if(newKey==null)
            return;

        int hash=hash(newKey);
        HashNodeImplementation<K,V> newEntry = new HashNodeImplementation<K,V>(newKey, data, null);

        if(table[hash] == null){
            table[hash] = newEntry;
        }else{
            HashNodeImplementation<K,V> previous = null;
            HashNodeImplementation<K,V> current = table[hash];

            while(current != null){
                if(current.key.equals(newKey)){
                    newEntry.next=current.next;
                    if(previous==null){
                        table[hash]=newEntry;
                    }
                    else{
                        previous.next=newEntry;
                    }
                    return;
                }
                previous=current;
                current = current.next;
            }
            if(previous != null) {
                previous.next = newEntry;
            }
        }
        size++;
    }
    //CONTAINS
    public boolean contains(K key) {
  		if(size==0) {
  			return false;
  		}
  		
  		int bucketIndex = hash(key);
  		HashNodeImplementation<K, V> head = table[bucketIndex];
  		while(head!=null) {
  			if(head.key.equals(key)) {
  				return true;
  			}
  			head = head.next;
  		}
  		return false;
  	}

    public V get(K key){
        int hash = hash(key);
        if (table[hash] != null) {
        	HashNodeImplementation<K, V> temp = table[hash];
            while (temp != null) {
                if (temp.key.equals(key))
                    return temp.value;
                temp = temp.next;
            }
        }
        return null;
    }

    public boolean delete(K deleteKey){

        int hash=hash(deleteKey);

        if (table[hash] != null) {
        	HashNodeImplementation<K, V> previous = null;
        	HashNodeImplementation<K, V> current = table[hash];

            while (current != null) {
                if (current.key.equals(deleteKey)) {
                    if (previous == null) {
                        table[hash] = table[hash].next;
                    } else {
                        previous.next = current.next;
                    }
                    return true;
                }
                previous = current;
                current = current.next;
            }
            size--;
        }
        return false;

    }
    
    public int size() 
	{
		return size;
	}

    public void print(){

        for(int i=0;i<capacityOfHash;i++){
            if(table[i]!=null){
            	HashNodeImplementation<K, V> entry=table[i];
                while(entry!=null){
                    System.out.print("["+entry.key+"->"+entry.value+"]" +" ");
                    entry=entry.next;
                }
            }
        }

    }


}
